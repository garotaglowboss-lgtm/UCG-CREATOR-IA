# UGC Creator IA

Projeto React + TypeScript + Vite para a plataforma UGC Creator IA.

## Incluído

- Landing page SaaS premium
- Logo premium em `public/logo.png`
- Isa / estrategista IA
- Product Scanner
- Image Creator
- Video Creator
- Copy Creator
- Biblioteca de prompts
- Planos em **BRL בלבד**:
  - Mensal: R$ 59,90/mês
  - Anual: R$ 297,00/ano
- Tela de confirmação com checkbox de termos
- Cupom
- Fluxo de cadastro
- Preparação para Stripe Checkout via variáveis de ambiente
- Layout responsivo

## Instalação

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Stripe

Copie `.env.example` para `.env` e configure:

```text
VITE_STRIPE_MONTHLY_CHECKOUT_URL=
VITE_STRIPE_ANNUAL_CHECKOUT_URL=
```

Para produção, a criação de sessões de Checkout deve ser feita no backend/servidor, mantendo chaves secretas fora do frontend.
