import { useState } from "react";

type Plan = "monthly" | "annual";
type Screen = "home" | "access" | "confirm" | "register";

const monthlyFeatures = [
  "Acesso à plataforma",
  "Isa — estrategista IA",
  "Analisador de produtos",
  "Image Creator",
  "Video Creator",
  "Copy Creator",
  "Biblioteca de prompts",
];

const annualFeatures = [
  "Tudo do plano mensal",
  "Biblioteca completa",
  "Novos conteúdos",
  "Acesso anual por 12 meses",
  "Todos os recursos disponíveis",
];

function Logo() {
  return (
    <img className="site-logo" src="/logo.png" alt="UGC Creator IA" />
  );
}

function App() {
  const [screen, setScreen] = useState<Screen>("home");
  const [plan, setPlan] = useState<Plan>("monthly");
  const [coupon, setCoupon] = useState("");
  const [accepted, setAccepted] = useState(false);
  const [faq, setFaq] = useState<number | null>(null);

  const selectedName =
    plan === "annual" ? "UGC Creator Pro — Anual" : "UGC Creator — Mensal";
  const selectedPrice = plan === "annual" ? "R$ 297,00/ano" : "R$ 59,90/mês";

  function choosePlan(value: Plan) {
    setPlan(value);
    setScreen("confirm");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function handlePayment() {
    if (!accepted) return;

    const url =
      plan === "annual"
        ? import.meta.env.VITE_STRIPE_ANNUAL_CHECKOUT_URL
        : import.meta.env.VITE_STRIPE_MONTHLY_CHECKOUT_URL;

    if (url) {
      window.location.href = url;
      return;
    }

    // Fallback: registration page until the real Stripe Checkout URL is configured.
    setScreen("register");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  return (
    <div className="app">
      <header className="header">
        <button className="brand" onClick={() => setScreen("home")} aria-label="Início">
          <Logo />
          <span>
            <strong>UGC</strong> CREATOR IA
          </span>
        </button>

        <nav>
          <button onClick={() => setScreen("home")}>Início</button>
          <button onClick={() => setScreen("access")}>Recursos</button>
          <button onClick={() => setScreen("access")}>Preços</button>
          <button onClick={() => document.getElementById("faq")?.scrollIntoView({ behavior: "smooth" })}>
            Dúvidas
          </button>
        </nav>

        <button className="header-cta" onClick={() => setScreen("access")}>
          Começar agora →
        </button>
      </header>

      {screen === "home" && (
        <>
          <section className="hero">
            <div className="hero-copy">
              <span className="eyebrow">INTELIGÊNCIA PARA CRIADORES</span>
              <h1>
                Crie conteúdo.
                <br />
                <em>Venda mais.</em>
              </h1>
              <p>
                A plataforma de IA para transformar produtos em conteúdo UGC,
                imagens, vídeos, prompts e copies prontos para criar.
              </p>
              <div className="hero-actions">
                <button className="primary" onClick={() => setScreen("access")}>
                  Começar agora →
                </button>
                <button className="secondary" onClick={() => setScreen("access")}>
                  Explorar plataforma
                </button>
              </div>
              <div className="stats">
                <span><b>01</b><small>PRODUTO</small></span>
                <span><b>∞</b><small>POSSIBILIDADES</small></span>
                <span><b>IA</b><small>ESTRATÉGIA</small></span>
              </div>
            </div>

            <div className="dashboard-card">
              <div className="dash-top">
                <span>UGC CREATOR IA</span><span className="online">● ONLINE</span>
              </div>
              <div className="dash-body">
                <aside>
                  <Logo />
                  <div className="nav-active">✦<small>Início</small></div>
                  <div>◇<small>Produtos</small></div>
                  <div>◇<small>Imagens</small></div>
                  <div>▶<small>Vídeos</small></div>
                  <div>✧<small>Prompts</small></div>
                </aside>
                <main>
                  <span className="muted">PAINEL DE CRIAÇÃO</span>
                  <h2>Olá, criadora.</h2>
                  <div className="isa-card">
                    <div className="isa-head">
                      <span className="isa-icon">✦</span>
                      <span><b>ISA</b><small>ESTRATEGISTA IA</small></span>
                      <label>IA ATIVA</label>
                    </div>
                    <h3>O que vamos criar <em>hoje?</em></h3>
                    <p>Envie um produto e deixe a IA encontrar o melhor caminho para seu conteúdo.</p>
                    <button onClick={() => setScreen("access")}>Analisar produto →</button>
                  </div>
                  <div className="dash-tools">
                    <div>◇<b>Imagem</b><small>UGC & POV</small></div>
                    <div>▶<b>Vídeo</b><small>Roteiros IA</small></div>
                    <div>✦<b>Copy</b><small>Hooks & CTA</small></div>
                  </div>
                </main>
              </div>
            </div>
          </section>

          <section className="section">
            <div className="section-heading">
              <h2>Tudo para criar.<br /><em>Em um só lugar.</em></h2>
              <p>Uma central de criação pensada para produzir conteúdo constantemente sem começar do zero todos os dias.</p>
            </div>
            <div className="feature-grid">
              {[
                ["01", "ESTRATÉGIA COM IA", "Isa", "Sua estrategista para analisar produtos, encontrar ângulos e transformar ideias em conteúdo."],
                ["02", "ANÁLISE INTELIGENTE", "Product Scanner", "Descubra como apresentar cada produto e qual formato de conteúdo explorar."],
                ["03", "PROMPTS VISUAIS", "Image Creator", "Crie prompts para imagens UGC, POV, lifestyle, produto e cenas comerciais."],
                ["04", "VÍDEOS QUE PRENDEM", "Video Creator", "Estruture cenas, movimentos, ganchos e roteiros para vídeos curtos."],
                ["05", "BIBLIOTECA PREMIUM", "Prompt Library", "Uma biblioteca organizada para acelerar sua criação todos os dias."],
                ["06", "TEXTO QUE CONVERTE", "Copy Creator", "Ganchos, CTAs, roteiros, legendas e textos para seus conteúdos."],
              ].map(([n, tag, title, desc]) => (
                <article className="feature" key={n}>
                  <span className="feature-number">{n}</span>
                  <span className="eyebrow">{tag}</span>
                  <h3>{title}</h3>
                  <p>{desc}</p>
                  <span className="arrow">→</span>
                </article>
              ))}
            </div>
          </section>

          <section className="isa-section">
            <div>
              <span className="eyebrow">02 / INTELIGÊNCIA ✦ SUA ESTRATEGISTA</span>
              <h2>Conheça a<br /><em>Isa.</em></h2>
              <p>Não é apenas um gerador de prompts. A Isa analisa o produto, entende o contexto e ajuda você a transformar aquele produto em conteúdo.</p>
              <ul>
                <li><b>01</b> Analisa o produto</li>
                <li><b>02</b> Define o melhor formato</li>
                <li><b>03</b> Cria a estratégia visual</li>
              </ul>
              <button className="secondary" onClick={() => setScreen("access")}>Conhecer a Isa →</button>
            </div>
            <div className="orb"><Logo /><span>ANÁLISE<br /><small>Produto identificado</small></span><strong>✓ ESTRATÉGIA<br /><small>POV / formato</small></strong></div>
          </section>

          <section className="steps">
            <h2>Do produto ao<br /><em>conteúdo.</em></h2>
            <p>Menos tempo pensando no que postar. Mais tempo criando.</p>
            <div className="steps-grid">
              <article><b>01</b><h3>Escolha seu produto</h3><p>Envie uma foto ou informe qual produto você quer divulgar.</p></article>
              <article><b>02</b><h3>A IA analisa</h3><p>A plataforma identifica possibilidades de conteúdo e posicionamento.</p></article>
              <article><b>03</b><h3>Crie seu conteúdo</h3><p>Gere prompts, roteiros, imagens e ideias em poucos minutos.</p></article>
            </div>
          </section>
        </>
      )}

      {screen === "access" && (
        <section className="access-page">
          <div className="access-intro">
            <span className="eyebrow">04 / ACESSO</span>
            <h1>Escolha seu<br /><em>acesso.</em></h1>
            <p>Comece a construir uma rotina de criação mais inteligente.</p>
          </div>

          <div className="plans">
            <article className={`plan ${plan === "monthly" ? "selected" : ""}`}>
              <span className="plan-label">ACESSO COMPLETO</span>
              <h2>UGC Creator</h2>
              <span className="period">MENSAL</span>
              <p>Para começar a explorar a plataforma.</p>
              <div className="price"><small>R$</small> 59,90 <span>/mês</span></div>
              <ul>{monthlyFeatures.map(x => <li key={x}>✓ {x}</li>)}</ul>
              <button className="secondary full" onClick={() => choosePlan("monthly")}>Escolher mensal →</button>
            </article>

            <article className={`plan popular ${plan === "annual" ? "selected" : ""}`}>
              <span className="popular-badge">✦ MAIS POPULAR</span>
              <span className="plan-label">ACESSO COMPLETO</span>
              <h2>UGC Creator Pro</h2>
              <span className="period">ANUAL</span>
              <p>A experiência completa para criadoras.</p>
              <div className="price"><small>R$</small> 297,00 <span>/ano</span></div>
              <p className="one-time">⚡ Pagamento único — não recorrente</p>
              <ul>{annualFeatures.map(x => <li key={x}>✓ {x}</li>)}</ul>
              <button className="primary full" onClick={() => choosePlan("annual")}>Quero acesso completo →</button>
            </article>
          </div>
        </section>
      )}

      {screen === "confirm" && (
        <section className="confirm-page">
          <div className="confirm-copy">
            <span className="eyebrow">05 / FINALIZAÇÃO</span>
            <h1>Confirme seu acesso.</h1>
            <p>Antes de continuar, confirme que você concorda com os termos da entrega digital.</p>

            <div className="selected-plan">
              <small>PLANO SELECIONADO</small>
              <strong>{selectedName}</strong>
              <b>{selectedPrice}</b>
            </div>

            <label className="coupon-label">
              🎟 TEM UM CUPOM?
              <input value={coupon} onChange={e => setCoupon(e.target.value)} placeholder="CUPOM / CÓDIGO" maxLength={40} />
            </label>

            <label className="terms">
              <input type="checkbox" checked={accepted} onChange={e => setAccepted(e.target.checked)} />
              <span><strong>Concordo:</strong> estou adquirindo um produto digital e o acesso será liberado após a confirmação do pagamento.</span>
            </label>

            <button className="primary confirm-btn" disabled={!accepted} onClick={handlePayment}>
              Confirmar e continuar →
            </button>

            <p className="payment-note">🔒 Pagamento processado pela Stripe.</p>
          </div>
        </section>
      )}

      {screen === "register" && (
        <section className="register-page">
          <div className="register-card">
            <Logo />
            <h1>Crie sua conta</h1>
            <p>Finalize seu cadastro para acessar o UGC Creator IA.</p>
            <label>Nome<input placeholder="Seu nome" /></label>
            <label>E-mail<input type="email" placeholder="seu@email.com" /></label>
            <label>Senha<input type="password" placeholder="Mínimo de 8 caracteres" /></label>
            <button className="primary full" onClick={() => alert("Configure o Checkout/Backend da Stripe para ativar a conta automaticamente.")}>Criar conta →</button>
            <button className="text-button" onClick={() => setScreen("confirm")}>← Voltar</button>
          </div>
        </section>
      )}

      <section className="faq" id="faq">
        <span className="eyebrow">SUPORTE E DÚVIDAS</span>
        <h2>Precisa de ajuda?</h2>
        <p>Confira as dúvidas mais comuns sobre a plataforma.</p>
        {[
          ["Preciso de um computador potente para gerar vídeos?", "Não necessariamente. A plataforma pode gerar prompts e roteiros no navegador; o processamento de ferramentas externas depende do serviço utilizado."],
          ["Quais plataformas de IA são utilizadas?", "A plataforma organiza estratégias e prompts para diferentes fluxos de criação. As ferramentas externas podem variar conforme o conteúdo."],
          ["Posso cancelar minha assinatura?", "O plano mensal e o plano anual possuem condições diferentes. Configure aqui sua política comercial antes de publicar a página."],
          ["Como adapto os prompts para outros geradores?", "Os prompts podem ser ajustados ao gerador escolhido, mantendo produto, enquadramento, iluminação, estilo e objetivo."],
          ["Qual plataforma de pagamento é utilizada?", "O checkout desta versão está preparado para receber URLs de Checkout da Stripe em variáveis de ambiente."],
        ].map(([q, a], i) => (
          <div className="faq-item" key={q}>
            <button onClick={() => setFaq(faq === i ? null : i)}>{q}<span>{faq === i ? "⌃" : "⌄"}</span></button>
            {faq === i && <p>{a}</p>}
          </div>
        ))}
      </section>

      <footer>
        <Logo />
        <span>© 2026 UGC CREATOR IA</span>
        <span>CRIADO PARA CRIADORAS</span>
      </footer>
    </div>
  );
}

export default App;