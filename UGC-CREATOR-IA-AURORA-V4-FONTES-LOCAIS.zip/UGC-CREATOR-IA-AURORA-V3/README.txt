UGC CREATOR IA — V3 PREMIUM

FONTES LOCAIS
A tipografia usa Inter e Outfit em WOFF2, sem Google Fonts/CDN em runtime.
As fontes são obtidas pelos pacotes oficiais @fontsource/inter e @fontsource/outfit durante npm install e copiadas automaticamente para public/fonts pelo postinstall.

Depois de extrair:
1. npm install
2. npm run dev

O postinstall cria:
public/fonts/fonts.css
public/fonts/inter-300-latin.woff2 ... inter-900-latin.woff2
public/fonts/inter-300-latin-ext.woff2 ... inter-900-latin-ext.woff2
public/fonts/outfit-300-latin.woff2 ... outfit-900-latin.woff2
public/fonts/outfit-300-latin-ext.woff2 ... outfit-900-latin-ext.woff2

A referência de fonte é baseada na distribuição Google Fonts/Fontsource. Inter e Outfit são open source sob OFL.

SUPABASE
Mantenha seu .env.local original com VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY.

STRIPE
Preencha VITE_STRIPE_MONTHLY_CHECKOUT_URL e VITE_STRIPE_ANNUAL_CHECKOUT_URL quando conectar os links de checkout.
