import fs from 'node:fs/promises';
import path from 'node:path';

const root = process.cwd();
const dest = path.join(root, 'public', 'fonts');
await fs.mkdir(dest, { recursive: true });

const families = [
  { pkg: '@fontsource/inter', prefix: 'inter', family: 'Inter' },
  { pkg: '@fontsource/outfit', prefix: 'outfit', family: 'Outfit' },
];
const weights = [300, 400, 500, 600, 700, 800, 900];

for (const { pkg, prefix } of families) {
  for (const weight of weights) {
    for (const subset of ['latin-ext', 'latin']) {
      const source = path.join(root, 'node_modules', pkg, 'files', `${prefix}-${subset}-${weight}-normal.woff2`);
      const target = path.join(dest, `${prefix}-${weight}-${subset}.woff2`);
      await fs.copyFile(source, target);
    }
  }
}

const css = `/* UGC CREATOR IA — self-hosted Inter + Outfit. Files are copied from @fontsource during npm install. */\n\n`;
const latinRange = 'U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD';
const latinExtRange = 'U+0100-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+0304,U+0308,U+0329,U+1D00-1DBF,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF';
for (const [family, prefix] of [['Inter','inter'],['Outfit','outfit']]) {
  for (const weight of weights) {
    css += `@font-face { font-family: '${family}'; font-style: normal; font-weight: ${weight}; font-display: swap; src: url('./${prefix}-${weight}-latin-ext.woff2') format('woff2'); unicode-range: ${latinExtRange}; }\n`;
    css += `@font-face { font-family: '${family}'; font-style: normal; font-weight: ${weight}; font-display: swap; src: url('./${prefix}-${weight}-latin.woff2') format('woff2'); unicode-range: ${latinRange}; }\n`;
  }
}
await fs.writeFile(path.join(dest, 'fonts.css'), css);
console.log('UGC CREATOR IA: fontes locais copiadas para public/fonts.');
