/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_SUPABASE_URL: string
  readonly VITE_SUPABASE_ANON_KEY: string
  readonly VITE_STRIPE_MONTHLY_CHECKOUT_URL: string
  readonly VITE_STRIPE_ANNUAL_CHECKOUT_URL: string
}

interface ImportMeta { readonly env: ImportMetaEnv }
