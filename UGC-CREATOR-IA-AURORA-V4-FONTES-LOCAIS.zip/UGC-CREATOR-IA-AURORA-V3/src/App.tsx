import { useState } from "react";
import type { FormEvent } from "react";
import { supabase } from "./lib/supabase";

type Plan = "monthly" | "annual" | null;
type View = "home" | "confirm" | "register";

const gallery = [
  { src: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=1200&q=88", tag: "01 / UGC", title: "Moda em contexto" },
  { src: "https://images.unsplash.com/photo-1525507119028-ed4c629a60a3?auto=format&fit=crop&w=1200&q=88", tag: "02 / PRODUCT", title: "Produto em cena" },
  { src: "https://images.unsplash.com/photo-1556228578-8c89e6adf883?auto=format&fit=crop&w=1200&q=88", tag: "03 / BEAUTY", title: "Beauty editorial" },
  { src: "https://images.unsplash.com/photo-1547887538-e3a2f32cb1cc?auto=format&fit=crop&w=1200&q=88", tag: "04 / LIFESTYLE", title: "Lifestyle natural" },
  { src: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=1200&q=88", tag: "05 / PRODUCT", title: "Produto premium" },
  { src: "https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=1200&q=88", tag: "06 / CAMPAIGN", title: "Direção de campanha" },
  { src: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1200&q=88", tag: "07 / CREATIVE", title: "Creator look" },
  { src: "https://images.unsplash.com/photo-1523381210434-271e8be1f52b?auto=format&fit=crop&w=1200&q=88", tag: "08 / UGC", title: "Conteúdo para social" },
];

const reels = [
  { src: "https://images.unsplash.com/photo-1556761175-b413da4baf72?auto=format&fit=crop&w=720&q=88", type: "UGC / LIFESTYLE", metric: "+12,4k views" },
  { src: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=720&q=88", type: "POV / PRODUCT", metric: "9:16 vertical" },
  { src: "https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&w=720&q=88", type: "DEMO / SHORT", metric: "Hook + CTA" },
  { src: "https://images.unsplash.com/photo-1521737711867-e3b97375f902?auto=format&fit=crop&w=720&q=88", type: "CREATOR / UGC", metric: "Natural take" },
  { src: "https://images.unsplash.com/photo-1499750310107-5fef28a66643?auto=format&fit=crop&w=720&q=88", type: "PRODUCT / POV", metric: "Ready to post" },
];

const monthly = ["Image Creator", "Video Creator", "Analisador de produtos", "Prompt Creator", "Copy Creator", "Biblioteca de prompts"];
const annual = ["Tudo do mensal", "Acesso por 12 meses", "Biblioteca completa", "Novos recursos e conteúdos", "Todos os módulos da plataforma", "Isa — estrategista complementar"];

const go = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });

export default function App() {
  const [view, setView] = useState<View>("home");
  const [plan, setPlan] = useState<Plan>(null);
  const [terms, setTerms] = useState(false);
  const [coupon, setCoupon] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [password2, setPassword2] = useState("");
  const [loading, setLoading] = useState(false);

  const choosePlan = (p: Plan) => { setPlan(p); setView("confirm"); window.scrollTo({ top: 0 }); };
  const selectedFeatures = plan === "annual" ? annual : monthly;

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!name || !email || !password || !password2) return alert("Preencha todos os campos.");
    if (password.length < 6) return alert("A senha precisa ter pelo menos 6 caracteres.");
    if (password !== password2) return alert("As senhas não coincidem.");
    setLoading(true);
    try {
      const { error } = await supabase.auth.signUp({
        email: email.trim(), password,
        options: { data: { name: name.trim(), plan: plan === "annual" ? "annual" : "monthly" } },
      });
      if (error) throw error;
      alert("Conta criada. Verifique seu e-mail para confirmar o acesso.");
    } catch (err) { alert(err instanceof Error ? err.message : "Não foi possível criar sua conta."); }
    finally { setLoading(false); }
  };

  if (view !== "home") return <Checkout view={view} setView={setView} plan={plan} terms={terms} setTerms={setTerms} coupon={coupon} setCoupon={setCoupon} name={name} setName={setName} email={email} setEmail={setEmail} password={password} setPassword={setPassword} password2={password2} setPassword2={setPassword2} loading={loading} submit={submit} />;

  return <div className="site">
    <div className="announcement"><span>UGC CREATOR IA</span><b>IMAGENS · VÍDEOS · PROMPTS</b><a href="#acesso">começar agora ↗</a></div>
    <header className="nav">
      <button className="brand" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} aria-label="UGC Creator IA">
        <span className="brandMark">U</span><span>UGC CREATOR <strong>IA</strong></span>
      </button>
      <nav><button onClick={() => go("galeria")}>Galeria</button><button onClick={() => go("recursos")}>Recursos</button><button onClick={() => go("acesso")}>Acesso</button></nav>
      <button className="navCta" onClick={() => go("acesso")}>Entrar na plataforma <span>↗</span></button>
    </header>

    <main>
      <section className="hero">
        <div className="heroInner">
          <div className="heroLabel"><span>PLATAFORMA DE CRIAÇÃO COM IA</span><span>01 — 06</span></div>
          <div className="heroCenter">
            <p className="kicker">CRIE MAIS. PAREÇA REAL. PUBLIQUE MELHOR.</p>
            <h1>Seu produto.<br /><em>Seu conteúdo.</em><br />Sua próxima venda.</h1>
            <p className="heroText">Uma plataforma para transformar produtos em imagens, vídeos e criativos com estética profissional — sem começar do zero.</p>
            <div className="heroActions"><button className="primary" onClick={() => go("acesso")}>Começar agora <span>↗</span></button><button className="secondary" onClick={() => go("galeria")}>Ver criações</button></div>
          </div>
          <div className="heroStats"><div><b>01</b><span>IMAGE<br />CREATOR</span></div><div><b>02</b><span>VIDEO<br />CREATOR</span></div><div><b>03</b><span>PRODUCT<br />ANALYZER</span></div><div><b>04</b><span>COPY &<br />PROMPTS</span></div></div>
        </div>
      </section>

      <section className="heroGallery" aria-label="Exemplos de criações">
        <div className="heroImage large"><img src={gallery[0].src} alt="Exemplo de criação UGC" /><span>UGC / 01</span></div>
        <div className="heroImage small"><img src={gallery[2].src} alt="Exemplo de criação" /><span>BEAUTY / 03</span></div>
        <div className="heroImage small second"><img src={gallery[4].src} alt="Exemplo de produto" /><span>PRODUCT / 05</span></div>
      </section>

      <section className="introBand">
        <div className="sectionNo">01 / DIREÇÃO</div>
        <div><p className="kicker">A TECNOLOGIA FICA NOS BASTIDORES</p><h2>Você cuida da ideia.<br /><em>A plataforma cuida do resto.</em></h2></div>
        <p>O UGC CREATOR IA foi pensado para quem precisa criar conteúdo visual todos os dias sem abrir mão de estética, velocidade ou consistência.</p>
      </section>

      <section className="gallerySection" id="galeria">
        <div className="sectionHead"><div><p className="sectionNo">02 / GALERIA</p><p className="kicker">IMAGENS QUE PARECEM CONTEÚDO, NÃO MOCKUP</p><h2>Feito para<br /><em>parecer real.</em></h2></div><p>Referências comerciais, lifestyle, UGC e produto em contexto. A galeria é apenas uma amostra do tipo de direção que você pode criar.</p></div>
        <div className="masonry">{gallery.slice(1).map((item) => <figure key={item.src}><img src={item.src} alt={item.title} /><figcaption><span>{item.tag}</span><b>{item.title}</b></figcaption></figure>)}</div>
      </section>

      <div className="marquee"><div className="marqueeTrack"><span>AI UGC CREATIVES</span><i>•</i><span>PRODUCT STORIES</span><i>•</i><span>POV & LIFESTYLE</span><i>•</i><span>IMAGE TO VIDEO</span><i>•</i><span>HOOKS & CTAS</span><i>•</i><span>AI UGC CREATIVES</span><i>•</i><span>PRODUCT STORIES</span><i>•</i><span>POV & LIFESTYLE</span><i>•</i><span>IMAGE TO VIDEO</span><i>•</i></div></div>

      <section className="videoSection" id="videos">
        <div className="sectionHead videoHead"><div><p className="sectionNo">03 / VIDEO</p><p className="kicker">VIDEO CREATOR</p><h2>Da imagem ao<br /><em>movimento.</em></h2></div><p>Crie referências para vídeos verticais, UGC, POV, demonstrações e anúncios curtos com uma direção visual consistente.</p></div>
        <div className="reelRail">{reels.map((r, i) => <article className="reel" key={r.src}><img src={r.src} alt={r.type} /><div className="reelGradient" /><span className="reelPlay">▶</span><div className="reelMeta"><span>0{i + 1} / {r.type}</span><b>{r.metric}</b></div></article>)}</div>
      </section>

      <section className="resources" id="recursos">
        <div className="sectionHead"><div><p className="sectionNo">04 / RECURSOS</p><p className="kicker">UM ECOSSISTEMA, NÃO UM PAINEL CONFUSO</p><h2>As ferramentas<br /><em>trabalham juntas.</em></h2></div><p>O foco é o resultado. Cada recurso entra no momento certo para tirar você do produto bruto e levar até um criativo pronto.</p></div>
        <div className="resourceList">
          <Resource n="01" title="Image Creator" text="Direções visuais comerciais, lifestyle, UGC e produto." /><Resource n="02" title="Video Creator" text="Conceitos para vídeos verticais, POV, demo e short ads." /><Resource n="03" title="Product Analyzer" text="Ângulos de conteúdo, hooks e oportunidades a partir do produto." /><Resource n="04" title="Prompt Creator" text="Prompts estruturados para gerar com mais controle e consistência." /><Resource n="05" title="Copy Creator" text="Hooks, legendas, CTAs e textos para acompanhar cada criativo." /><Resource n="06" title="Isa" text="Estratégia complementar para orientar conteúdo e execução." />
        </div>
      </section>

      <section className="workflow"><div className="workflowInner"><p className="sectionNo">05 / FLUXO</p><h2>Um processo simples.<br /><em>Uma produção constante.</em></h2><div className="workflowGrid"><Flow n="01" title="Produto" text="Escolha o produto e o objetivo."/><Flow n="02" title="Direção" text="Encontre o estilo visual."/><Flow n="03" title="Criação" text="Gere imagem, vídeo e copy."/><Flow n="04" title="Publicação" text="Leve o criativo para seus canais."/></div></div></section>

      <section className="pricing" id="acesso">
        <div className="pricingIntro"><div><p className="sectionNo">06 / ACESSO</p><p className="kicker">COMECE NO SEU RITMO</p><h2>Seu conteúdo<br /><em>começa aqui.</em></h2></div><p>Escolha o acesso que faz sentido para sua rotina de criação.</p></div>
        <div className="pricingGrid"><Plan title="UGC Creator" label="MENSAL" price="59,90" period="/mês" features={monthly} onClick={() => choosePlan("monthly")} /><Plan title="UGC Creator Pro" label="ANUAL" price="297,00" period="/ano" features={annual} featured onClick={() => choosePlan("annual")} /></div>
      </section>

      <section className="faq"><div><p className="sectionNo">FAQ</p><p className="kicker">DÚVIDAS</p><h2>Antes de<br /><em>começar.</em></h2></div><div className="faqList"><Faq q="Preciso saber usar IA?" a="Não. A plataforma organiza as etapas e entrega direções prontas para você adaptar."/><Faq q="Posso usar para produtos da Shopee e TikTok?" a="Sim. O foco é criação de conteúdo visual para produtos e redes sociais. Sempre adapte o material às regras atuais de cada plataforma."/><Faq q="A Isa é a ferramenta principal?" a="Não. Isa é um recurso complementar. O núcleo do UGC CREATOR IA é criação de imagens, vídeos, prompts, análise e copy."/><Faq q="Como funciona o acesso?" a="Você escolhe o plano, aceita os termos, cria sua conta e segue para o pagamento."/></div></section>
    </main>
    <footer><div><span className="footerBrand">UGC CREATOR <b>IA</b></span><p>IMAGENS · VÍDEOS · CONTEÚDO</p></div><span>© 2026 UGC CREATOR IA</span></footer>
  </div>;
}

function Resource({n,title,text}:{n:string;title:string;text:string}) { return <article className="resource"><span>{n}</span><h3>{title}</h3><p>{text}</p><b>↗</b></article>; }
function Flow({n,title,text}:{n:string;title:string;text:string}) { return <article><span>{n}</span><h3>{title}</h3><p>{text}</p></article>; }
function Faq({q,a}:{q:string;a:string}) { return <details><summary>{q}<span>+</span></summary><p>{a}</p></details>; }
function Plan({title,label,price,period,features,featured,onClick}:{title:string;label:string;price:string;period:string;features:string[];featured?:boolean;onClick:()=>void}) { return <article className={`priceCard ${featured ? "featured" : ""}`}>{featured && <span className="popular">ACESSO ANUAL</span>}<p className="planLabel">{label}</p><h3>{title}</h3><div className="price"><small>R$</small>{price}<span>{period}</span></div><div className="priceRule" />{features.map(x => <p className="feature" key={x}><b>+</b>{x}</p>)}<button onClick={onClick}>{featured ? "Quero acesso completo" : "Começar no mensal"}<span>↗</span></button></article>; }

function Checkout(props: any) {
  const {view,setView,plan,terms,setTerms,coupon,setCoupon,name,setName,email,setEmail,password,setPassword,password2,setPassword2,loading,submit} = props;
  const isAnnual = plan === "annual"; const features = isAnnual ? annual : monthly; const planName = isAnnual ? "UGC Creator Pro" : "UGC Creator"; const price = isAnnual ? "R$ 297,00" : "R$ 59,90";
  return <div className="checkout"><button className="back" onClick={() => setView(view === "register" ? "confirm" : "home")}>← voltar</button><div className="checkoutTop"><p className="sectionNo">{view === "confirm" ? "01 / 02" : "02 / 02"}</p><p className="kicker">{view === "confirm" ? "CONFIRMAÇÃO" : "CADASTRO"}</p><h1>{view === "confirm" ? "Seu acesso começa aqui." : "Crie sua conta."}</h1></div>{view === "confirm" ? <div className="checkoutGrid"><section className="checkoutCard"><p className="kicker">PLANO SELECIONADO</p><h2>{planName}</h2><div className="checkoutPrice">{price}<span>{isAnnual ? "/ano" : "/mês"}</span></div><div className="checkoutRule"/><label>CUPOM<div className="coupon"><input value={coupon} onChange={e=>setCoupon(e.target.value.toUpperCase())} placeholder="CÓDIGO"/><button type="button" onClick={()=>alert(coupon?`Cupom ${coupon} informado.`:"Digite um cupom.")}>Aplicar</button></div></label><label className="terms"><input type="checkbox" checked={terms} onChange={e=>setTerms(e.target.checked)}/><span>Li e aceito os termos de uso e a política de privacidade.</span></label><button className="primary full" onClick={()=>{if(!terms)return alert("Aceite os termos para continuar.");setView("register");window.scrollTo({top:0})}}>Continuar para cadastro ↗</button></section><aside className="summary"><p className="kicker">INCLUÍDO</p>{features.map(x=><div key={x}><span>+</span>{x}</div>)}</aside></div> : <form className="register" onSubmit={submit}><div className="selected"><span>{planName}</span><b>{price}</b></div><label>Nome<input value={name} onChange={e=>setName(e.target.value)} placeholder="Seu nome"/></label><label>E-mail<input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="seu@email.com"/></label><label>Senha<input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Mínimo de 6 caracteres"/></label><label>Confirmar senha<input type="password" value={password2} onChange={e=>setPassword2(e.target.value)} placeholder="Digite novamente"/></label><button className="primary full" disabled={loading}>{loading?"Criando conta...":"Criar minha conta ↗"}</button></form>}</div>;
}
